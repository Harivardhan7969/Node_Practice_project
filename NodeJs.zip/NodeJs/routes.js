const express = require('express');
const router = express.Router();
const { createEmployee, getEmployees, getEmployeeById, updateEmployee, deleteEmployee } = require('./queries.js');
const bcrypt = require('bcrypt');
const pool = require("./db.js");
const session = require('express-session');
const saltRounds = 10;
const password = 's0/\/\P4$$w0rD';
router.use(express.json());
router.use(session({
  secret: 'abcdef',
  resave: false,
  saveUninitialized: false
}));
router.get('/', (req, res) => {
    res.send('Express router lication');
});
router.post('/employees', (req, res) => {
    let { name, email, role, password } = req.body;
    bcrypt.hash(password, saltRounds, function (err, hash) {
        createEmployee([name, email, role, hash]).then(dbresponse =>
            res.send(dbresponse)
        ).catch((error) => {
            console.log("inside post error");
            console.log(error);
            res.send(error);
        })
    });
});

router.post('/logout', (req, res) => {
    const { email } = req.body;
    req.session.destroy((err) => {
      if (err) {
        res.status(500).send(err);
      } else {
        res.send('Logged out successfully');
      }
    });
  });
router.post('/login', (req, res) => {
    const { email, password } = req.body;
    pool.query('SELECT * FROM employees2 WHERE email = $1', [email], (err, result) => {
        if (err) {
            res.status(500).send(err);
        } else if (result.rows.length === 0) {
            res.status(401).send('email; or password incorrect');
        } else {
            const hashedPassword = result.rows[0].password;
            bcrypt.compare(password, hashedPassword, (err, isValid) => {
                if (err) {
                    res.status(500).send(err);
                } else if (!isValid) {
                    res.status(401).send('email or password incorrect');
                } else {
                    req.session.email = 'John Doe';
                    res.send('Logged in successfully');
                }
            });
        }
    });
});

router.get('/getEmployees', (req, res) => {
    getEmployees().then(dbres => {
        console.log(dbres);
        res.send(dbres)
    }
    ).catch(error => {
        console.log("Error: " + error);
        res.send(error);
    })
})
router.get('/getEmpById/:id', (req, res) => {
    console.log("entry 1");
    const id = req.params.id;
    console.log("entry 2 " + id);
    getEmployeeById([id]).then((dbresponse) => {
        console.log(dbresponse);
        res.send(dbresponse)
    }
    ).catch(error => {
        console.log("Error: " + error);
        res.send(error);
    })
})
router.put('/updateEmp/:id', (req, res) => {
    const id = req.params.id;
    let { name, email, role, salary } = req.body;
    if (req.params.id === id) {
        updateEmployee([name, email, role, salary, id]).then(
            (dbresponse) => {
                console.log("inside updateEmployee");
                console.log(dbresponse);
                res.send(dbresponse)
            }
        ).catch((error) => {
            console.log("inside put error");
            console.log(error);
            res.send(error);
        })
    }

})
router.delete('/deleteEmp/:id', (req, res) => {
    const id = req.params.id;
    deleteEmployee([id]).then(dbresponse =>
        res.send(dbresponse.body)
    ).catch(error => {
        console.log("Error: " + error);
        res.send(error);
    })
})


router.get('*', (req, res) => {
    res.send("404 not found");
});

module.exports = router;